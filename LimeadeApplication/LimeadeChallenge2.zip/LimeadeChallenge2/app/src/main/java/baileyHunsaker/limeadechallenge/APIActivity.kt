package baileyHunsaker.limeadechallenge
//API logic, and displays the current time.
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import com.google.gson.GsonBuilder
import okhttp3.*
import java.io.IOException
import java.util.*
import java.util.concurrent.TimeUnit

class APIActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_api)
        var locations = populateLocations()

        //I wait here for a second because timezoneDb onl allows one query a second.
        for (location in locations) {
            fetchTime(location)
            TimeUnit.SECONDS.sleep(1L)
        }

        val prevButton = findViewById<Button>(R.id.problem1Button)
        prevButton.setOnClickListener {
            val intent = Intent(this, problem3::class.java)
            startActivity(intent)
        }
    }

    //Gets the time at a location from timezonedb. Must know the latitude and longitude of the location.
    fun fetchTime(location: Location) {
        val url =
            "http://api.timezonedb.com/v2.1/get-time-zone?key=WTRAXNNTAEET&format=json&by=position&lat=" + location.lat + "&lng=" + location.long
        val httpClient = OkHttpClient()
        val request = Request.Builder().url(url).build()

        httpClient.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                println("Failed to execute")
            }

            override fun onResponse(call: Call, response: Response) {
                val body = response?.body()?.string()
                val gson = GsonBuilder().create()
                val dateFeed = gson.fromJson(body, Date::class.java)

                runOnUiThread {
                    val linearLayout: LinearLayout = findViewById<LinearLayout>(R.id.linearLayout2)
                    //val time = dateFeed.datetime
                    val time = dateFeed.formatted
                    val temp = TextView(getBaseContext())
                    temp.text = location.name + ": " + time
                    temp.textSize = 22f
                    temp.setTextColor(Color.WHITE)
                    temp!!.typeface = Typeface.create("sans-serif-smallcaps", Typeface.NORMAL)
                    linearLayout.addView(temp)
                }
            }
        })
    }

    //populate the locations you want to see. Ideally this would be done using fetchLocation, but I had a hard time synchronizing the threads.
    fun populateLocations(): ArrayList<Location> {
        //Populate the locations we want to show.
        var locations = ArrayList<Location>()
        locations.add(Location("Bellevue", 47.6101497, -122.2015159))
        locations.add(Location("Denver", 39.7392358, -104.990251))
        locations.add(Location("Gatineau", 45.4765446, -75.7012723))
        locations.add(Location("Oldenburg", 53.1434501, 8.214552099999999))
        return locations
    }
}

//Class to read in the time from the timezoneDb API
class Date(val formatted : String){}

//Class to store location information
class Location {
    var name : String
    var lat : Double = 0.0
    var long : Double = 0.0

    constructor(name: String, lat: Double, long: Double) {
        this.name = name
        this.lat = lat
        this.long = long
    }
}

/*Originally, I wanted to query the Google places API to find the latitude and longitude of the locations,
 then save that to a Location object and feed those into the fetchTime function to get the time of those
 locations and display them. But, I had a hard time figuring out how to synchronize the threads and store
 the outputs I was getting. The code below is my attempt at this.

 //Gets the latitude and longitude of a location. This almost works, but I had a hard time figuring out how to wait for the threads to finish before moving on
   with the program.
   fun fetchLocation(place : String) : Location{
       val url = "https://maps.googleapis.com/maps/api/place/textsearch/json?query=" + place + "&key=AIzaSyAvlmztRGjFzUMqZo4NHtF3B-bbQZ_QvaM"
       val httpClient = OkHttpClient()
       val request = Request.Builder().url(url).build()
       var lat : Double = 0.0
       var lng : Double = 0.0

       httpClient.newCall(request).enqueue(object : Callback {
           override fun onFailure(call: Call, e: IOException) {
               println("Failed to execute")
               done = true
           }

           override fun onResponse(call: Call, response: Response){
               val body = response?.body()?.string()
               val gson = GsonBuilder().create()
               val locationFeed = gson.fromJson(body, LocationFeed::class.java)
               lat = locationFeed.results.get(0).geometry.location.lat
               lng = locationFeed.results.get(0).geometry.location.lng
           }
       })
       //wait here till the thread is done. I am having a hard time figuring out how to do that.
       return Location(place, lat, lng)
   }

//Classes to read in location information from Google Places API
class LocationFeed(val results : List<O>){}

class O(val formatted_address : String, val geometry : Geometry){}

class Geometry(val location : LatLngFeed){}

class LatLngFeed(val lat : Double, val lng : Double){}*/