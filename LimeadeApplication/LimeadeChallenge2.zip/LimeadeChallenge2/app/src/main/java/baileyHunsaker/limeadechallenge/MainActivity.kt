package baileyHunsaker.limeadechallenge
//Find the time at each location. Display it. Problem #1

import android.os.Bundle
import android.support.v7.app.AppCompatActivity;
import java.util.*
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        getTime("America/Los_Angeles", "Bellevue")
        getTime("America/Denver", "Denver")
        getTime("America/Toronto", "Gatineau")
        getTime("Europe/Berlin", "OldenBurg")

        val nextButton = findViewById<Button>(R.id.problem2Button)
        nextButton.setOnClickListener {
            val intent = Intent(this, APIActivity::class.java)
            startActivity(intent)
        }

    }

    fun getTime(timeZone : String, nameOfPlace : String){
        val linearLayout = findViewById<LinearLayout>(R.id.linearLayout)
        val temp = TextView(this)

        val checkTimeZone = TimeZone.getTimeZone(timeZone)
        println(checkTimeZone)
        val date = Calendar.getInstance(checkTimeZone)
        val formattedDate =  String.format("%02d" , date.get(Calendar.HOUR_OF_DAY))+":"+
                String.format("%02d" , date.get(Calendar.MINUTE))+":"+ String.format("%02d" , date.get(Calendar.SECOND))+":"+ String.format("%03d" , date.get(Calendar.MILLISECOND))
        temp.text = nameOfPlace + ": " + formattedDate
        temp.textSize = 22f
        temp.setTextColor(Color.WHITE)
        temp.typeface = Typeface.create("sans-serif-smallcaps", Typeface.NORMAL)
        linearLayout.addView(temp)
    }
}